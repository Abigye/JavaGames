package interfaces;
import game.GameTypeClass;

public interface ViewInterface  {
    /**
     *
     * This interface defines which methods the view must implement.
     *
     */
    public void displayWelcomeMessage();

    public void displayMoveRejectedMessage(char move);

    public void displayBoard(GameTypeClass mode);

    // Methods to request user input.
    public char requestMenuSelection();

    public GameTypeClass requestGameType();

    public String requestGameUI();




}
