package interfaces;

import GameUtil.Point;
import java.util.ArrayList;

public interface GameTypeInterface {
    /**
     *
     * This interface defines which methods a game type must implement.
     *
     */
    public final int minimumBoardRow = 8;
    public final int minimumBoardCol = 8;
    public final int minimumPenRow = 2;
    public final int minimumPenCol = 3;

    public int getBoardRows();

    public int getBoardCols();

    public int getSheepNum();

    public void setSheepPositions(ArrayList<Point> sheepPositions);

    public ArrayList<Point> getPen();
    public char chooseMove();

    public Point getDogPos();

    public ArrayList <Point> getSheepPositions();

    public boolean isValidMove(Point move);

    public boolean isPointInGrid(Point point);

    public void init(String[][] Board, String[][] SheepPen, Point DogPos, ArrayList <Point> SheepPosition, ArrayList <Point> PenPositions);

    public void moveDog(Point pos);

    public boolean checkMoveInput(char move);

    public void moveSheep();

}
