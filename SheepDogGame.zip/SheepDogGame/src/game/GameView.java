package game;
import GameTypes.FixedType;
import GameTypes.RandomType;
import GameUtil.Point;
import interfaces.*;
import GameUtil.Input;

public class GameView implements ViewInterface{
    /**
     * This class is used to interact with the user.
     *
     */

    public void displayWelcomeMessage() {
        System.out.println("Welcome to SheepDog!");
    }

    public void displayMoveRejectedMessage(char move) {
        System.out.println("The move (" + move + ") was rejected, please try again.");
    }

    public char requestMenuSelection() {
        // Display menu options.
        System.out.println("\n-------- MENU --------");
        System.out.println("(1) Start new game");
        System.out.println("(2) Change game type");
        System.out.println("(3) Change game ui");

        // Request and return user input.
        System.out.print("Select an option and confirm with enter or use any other key to quit: ");
        return Input.readCharFromUser();
    }

    public GameTypeClass requestGameType() {
        System.out.println("\n-------- CHOOSE TYPE --------");
        System.out.println("(1) Fixed");
        System.out.println("(2) Random");

        // Request user input.
        System.out.print("Select an option and confirm with enter (invalid input will select Fixed): ");
        char selectedType = Input.readCharFromUser();

        // Instantiate the selected game type class.
        switch (selectedType) {
            case '2':
                return new RandomType();
            default:
                return new FixedType();
        }
    }

    public String requestGameUI() {
        System.out.println("\n-------- CHOOSE UI --------");
        System.out.println("(1) Text-Based");
        System.out.println("(2) Graphic");

        // Request user input.
        System.out.print("Select an option and confirm with enter (invalid input will select text-Based): ");
        char selectedUI = Input.readCharFromUser();

        // Instantiate the selected game ui class.
        switch (selectedUI) {
            case '2':
                return "Graphic";
            default:
                return "Text-Based";
        }
    }

    public void displayBoard(GameTypeClass gameType) {
        System.out.println("\n-------- BOARD --------");

        int nrRows = gameType.getBoardRows();
        int nrCols = gameType.getBoardCols();
//        System.out.println("num of rows:" + nrRows + " num of cols:" + nrCols);

        String pos_value = "";

        for (int row = 0; row < nrRows; row++) {
            for (int col = 0; col < nrCols; col++) {
                Point point = new Point(row, col);
                if (point.isPointIn(gameType.getPen())){ // points in the pen
//                    System.out.println("Point x:" + point.x + " Point y " + point.y);
                    pos_value += "x ";
                }else if(gameType.getDogPos().samePoint(point)){ // dog's position
                    pos_value += "D ";
                }else if(point.isPointIn(gameType.getSheepPositions())){ // sheep's position
                    pos_value+="S ";
                } else{
                    pos_value += "_ ";
                }
            }
            pos_value += "\n";
        }
        System.out.print(pos_value);
    }


}
