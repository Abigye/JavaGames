package game;

import GameUtil.Input;
import GameUtil.Point;
import interfaces.GameTypeInterface;

import java.util.ArrayList;
import java.util.Random;

public class GameTypeClass implements GameTypeInterface {
    /**
     *
     * This class defines which methods common game types must implement.
     *
     */
    private final double minimumDistance = 2.0;
    private ArrayList<Point> penPositions;
    private ArrayList<Point> sheepPositions;
    private String[][] board;
    private String[][] sheepPen;
    private Point dogPos;

    @Override
    public int getBoardRows() {
        return this.board.length;
    }

    @Override
    public int getBoardCols() {
        return this.board[0].length;
    }

    @Override
    public int getSheepNum() {
        return this.sheepPositions.size();
    }

    @Override
    public void setSheepPositions(ArrayList<Point>sheepPositions) {
        this.sheepPositions = sheepPositions;
    }

    @Override
    public ArrayList <Point> getPen() {
        return this.penPositions;
    }

    @Override
    public char chooseMove() {
        System.out.println("Select a move: a for Left, d for Right, w for Up, s for down: ");
        return Input.readCharFromUser();
    }
    @Override
    public Point getDogPos() {
        return this.dogPos;
    }

    @Override
    public ArrayList <Point> getSheepPositions() {
        return this.sheepPositions;
    }

    @Override
    public boolean isValidMove(Point move) {
        if(move.isPointIn(penPositions)){
            System.out.println("Dog is in Pen!");
            return false;
        } else if(!isPointInGrid(move)){
            System.out.println("Dog is outside of grid!");
            return false;
        }else if(move.isPointIn(getSheepPositions())){
            System.out.println("Dog can not be in the same place as sheep");
            return false;
        }
        return true;
    }

    @Override
    public boolean isPointInGrid(Point point) {
        for (int i = 0; i<getBoardRows(); i++) {
            for (int j = 0; j < getBoardCols(); j++) {
                if(new Point(i,j).samePoint(point)){
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void init(String[][] Board, String[][] SheepPen, Point DogPos, ArrayList <Point> SheepPosition, ArrayList <Point> PenPositions) {
        this.board = Board;
        this.sheepPen = SheepPen;
        this.dogPos =  DogPos;
        this.sheepPositions = SheepPosition;
        this.penPositions = PenPositions;
//        createPen();
    }

    @Override
    public void moveDog(Point pos) {
        this.dogPos = pos;
    }

    @Override
    public boolean checkMoveInput(char move) {
        Character[] moves = {'a','d','w','s'};
        for(char c:moves){
            if(move == c){
                return true;
            }
        }
        return false;
    }

    @Override
    public void moveSheep() {
        ArrayList<Point> ValidPositions = new ArrayList<>();
        Random rand = new Random();
        for (int i = 0; i < getSheepPositions().size(); i++) {

            Point sheep = getSheepPositions().get(i);
            double distance = getDogPos().distance(sheep);
            ArrayList<Point> sheepPos = sheep.allPointsAroundCurrent(); // gets all possible moves for a sheep
            ArrayList<Point> sheepValidPos = new ArrayList<>(); // possible valid moves for the sheep

            if (distance < minimumDistance){
                int maxDistanceIndex = 0;
//                System.out.println("Sheep move towards pen " + sheep.x + " " + sheep.y);
                for (int k = 0; k < sheepPos.size(); k++) {
                    if(isPointInGrid(sheepPos.get(k))){
                        if(!sheepPos.get(k).isPointIn(getSheepPositions())) {
                            if (!sheepPos.get(k).samePoint(getDogPos())) {
//                                System.out.println(sheepPos.get(k).x + "," + (sheepPos.get(k).y));
                                double BtnSheepAndDog = getDogPos().distance(sheepPos.get(k));
                                if (BtnSheepAndDog > getDogPos().distance(sheepPos.get(maxDistanceIndex))) {
                                    maxDistanceIndex = k;
                                }
                            }
                        }
                    }
                }
                ValidPositions.add(sheepPos.get(maxDistanceIndex));
            }else{
                for (int j = 0; j < sheepPos.size(); j++) {
                    if(isPointInGrid(sheepPos.get(j))){
                        if(!sheepPos.get(j).isPointIn(getSheepPositions())){
                            if(getDogPos().distance(sheepPos.get(j)) > minimumDistance){
                                sheepValidPos.add(sheepPos.get(j));
                            }
                        }
                    }
                }

                if (sheepValidPos.size() < 1){
                    ValidPositions.add(sheep);
                }else {
//                    get valid position that takes sheep to pen
                    ValidPositions.add(sheepValidPos.get(new Random().ints(1, 0, sheepValidPos.size()).findFirst().getAsInt()));
                }

            }
        }
        setSheepPositions(ValidPositions);
    }

    public void removeSheepFromPen(){
        for (int i = 0; i < getSheepPositions().size(); i++) {
            if(getSheepPositions().get(i).isPointIn(getPen())){
//                System.out.println("in pen " + getSheepPositions().get(i).x+ " " + getSheepPositions().get(i).y);
                getSheepPositions().remove(getSheepPositions().get(i));
            }
        }
    }
}
