package GameTypes;

import GameUtil.Point;
import game.GameTypeClass;

import java.util.ArrayList;
import java.util.Random;

public class RandomType extends GameTypeClass {
    /**
     *
     * This class defines the methods for the random game type.
     *
     */
    Random rand = new Random();
    public RandomType() {
        super();
        int row = generateRandomInt(minimumBoardRow , 15);
        int col = generateRandomInt(minimumBoardCol , 15);

        int penRow = generateRandomInt(minimumPenRow , row);
        int penCol = generateRandomInt(minimumPenCol , col);

//        System.out.println(((GameTypeInterface.minimumPenRow * GameTypeInterface.minimumPenCol)-1) + ", "+ ((penRow*penCol)-1));
        int numOfSheep = generateRandomInt((minimumPenRow * minimumPenCol)-1 ,
                (penRow*penCol)-1);

        String[][] board = new String[row][col]; // board size

        String[][] sheepPen = new String[penRow][penCol]; // pen size

        ArrayList<Point> penPositions = new ArrayList<>(); // points in sheep pen

        int pensize_x =  generateRandomInt(0 , row-penRow);
        int pensize_y = generateRandomInt(0 , col-penCol);

        // sets pen points
        for (int i = 0; i < penRow; i++) {
            penPositions.add(new Point(pensize_x + i,pensize_y));
            for (int j = 0; j < penCol; j++) {
                penPositions.add(new Point(pensize_x + i, pensize_y+j));
            }
        }

        ArrayList<Point> sheepPositions = new ArrayList<>(); // sheep positions

        Point dogPos = getRandomPosition( row , col,new Point(-1,-1),  penPositions,  sheepPositions); // dog position

        // set sheep random positions
        for (int k = 0; k < numOfSheep ; k++) {
            sheepPositions.add(getRandomPosition(row, col, dogPos, penPositions, sheepPositions));
        }

        init(board, sheepPen, dogPos, sheepPositions, penPositions);

    }

    public int generateRandomInt(int min, int max){
        return rand.ints(1, min, max).findFirst().getAsInt();
    }
    public Point getRandomPosition(int row,int col,Point dogPos, ArrayList<Point> pen, ArrayList<Point> sheep){
//        System.out.println(dogPos.x + " ," + dogPos.y);
        int x = generateRandomInt(0,row);
        int y = generateRandomInt(0,col);
        Point newPoint = new Point(x,y);
        if(dogPos.samePoint(newPoint) || newPoint.isPointIn(pen) || newPoint.isPointIn(sheep)){
            return getRandomPosition(row,col,dogPos, pen, sheep);
        }
        return newPoint;
    }

}
