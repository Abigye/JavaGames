package GameTypes;

import GameUtil.Point;
import game.GameTypeClass;


import java.util.ArrayList;

public class FixedType extends GameTypeClass{

    /**
     *
     * This class defines the methods for the fixed game type.
     *
     */
    public FixedType() {
        super();

        String[][] board = new String[minimumBoardRow][minimumBoardCol]; // board size

        String[][] sheepPen = new String[minimumPenRow][minimumPenCol]; // pen size

        Point dogPos = new Point(0,4); // dog position

        ArrayList<Point> sheepPositions = new ArrayList<>(); // sheep positions
        sheepPositions.add(new Point(1,1));
        sheepPositions.add(new Point(1,7));
        sheepPositions.add(new Point(2,5));
        sheepPositions.add(new Point(4,6));
        sheepPositions.add(new Point(7,3));

        ArrayList<Point> penPositions = new ArrayList<>(); // points in sheep pen
        int penrows = minimumPenRow;
        int pencols = minimumPenCol;
        int[] pensize = {4,2};

        for (int i = 0; i < penrows; i++) {
            penPositions.add(new Point(pensize[0] + i, pensize[1]));
            for (int j = 0; j < pencols; j++) {
                penPositions.add(new Point(pensize[0] + i, pensize[1]+j));
            }
        }
        init(board, sheepPen, dogPos, sheepPositions, penPositions);

    }

}
