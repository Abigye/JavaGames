package GameUtil;
import java.util.Scanner;

public class Input {
    /**
     *
     * This class provides a simple means of getting user input.
     *
     */
    private static final Scanner sc = new Scanner(System.in);

    public static int readIntFromUser()
    {
        // At least once and until valid input is received:
        do
        {
            // Wait for new input and check if it is an integer.
            if(sc.hasNextInt())
            {
                // Obtain the integer value and return it after
                // consuming the rest of the input line (if any).
                int input = sc.nextInt();
                sc.nextLine();
                return input;
            }

            // The input was not an integer, print an error and repeat.
            System.out.print("Please enter an integer: ");

            // Consume the rest of the line.
            sc.nextLine();
        }
        while(true);
    }

    public static char readCharFromUser()
    {
        // At least once and until valid input is received:
        do
        {
            // Wait for a new line of text to be entered.
            if(sc.hasNextLine())
            {
                // Obtain the user input.
                String input = sc.nextLine();

                // If a single char was entered, return it.
                if(input.length() == 1)
                    return input.charAt(0);
            }

            // Invalid input length, print an error and repeat.
            System.out.print("Please enter a single character: ");
        }
        while(true);
    }

    public static String readStringFromUser()
    {
        return sc.nextLine();
    }
}


