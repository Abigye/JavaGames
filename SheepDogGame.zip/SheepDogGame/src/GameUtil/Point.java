package GameUtil;

import java.util.ArrayList;

public class Point {

    /**
     *
     * This class defines a helper functions for locations of the dog and sheep for the game.
     *
     */
    public int x;
    public int y;

    public Point(){
        this.x = 0;
        this.y = 0;
    }

    public Point(int xpos, int ypos){
        this.x = xpos;
        this.y = ypos;
    }

     public boolean samePoint (Point point){
        return (this.x == point.x) && (this.y == point.y);
    }

    public Point moveRight () {
        this.y++;
        return new Point(x,this.y);
    }

    public Point moveLeft () {
        this.y--;
        return new Point(x,this.y);
    }

    public Point moveUp () {
        this.x--;
        return new Point(this.x,y);
    }

    public Point moveDown () {
        this.x++;
        return new Point(this.x,y);
    }
    public boolean isPointIn(ArrayList <Point> points) {
        for(Point q: points){
            if(this.samePoint(q)){
                return true;
            }
        }
        return false;
    }

    public Point convertCharToPoint(char move,Point point) {
        Point newPoint = new Point(point.x,point.y);
        if(move == 'a'){
            return newPoint.moveLeft();
        }else if(move == 'd'){
            return newPoint.moveRight();
        }else if (move == 'w'){
            return newPoint.moveUp();
        }else if (move == 's'){
            return newPoint.moveDown();
        }
        return newPoint;
    }

    public ArrayList<Point> allPointsAroundCurrent(){
        ArrayList<Point> points = new ArrayList<>();
        points.add(new Point(this.x-1, this.y)); // up
        points.add(new Point(this.x+1, this.y)); //down
        points.add(new Point(this.x, this.y-1)); // left
        points.add(new Point(this.x, this.y+1)); //right
        return points;
    }

    public double distance(Point b){
        double dis = Math.pow((b.y - this.y),2) + Math.pow((b.x - this.x),2);
        return Math.sqrt((dis));
    }
}
