package main;
import GameTypes.FixedType;
import GameTypes.RandomType;
import GameUtil.Input;
import GameUtil.Point;
import game.GameTypeClass;
import game.GameView;

public class Main {
    /**
     *
     * This class controls the flow of the game.
     */
    private int count = 0;
    GameView view = new GameView();
    Point pointClass = new Point();
    GameTypeClass mode;


    public static void main(String[] args) {
        Main game = new Main();
        game.beginSession();
    }

    public void beginSession()
    {
        view.displayWelcomeMessage();
        do
        {
            switch(view.requestMenuSelection())
            {
                case '1': startGame(); break;
                case '2': getGameType();break;
                case '3': view.requestGameUI();break;
                default: return;
            }
        }
        while(true);
    }
    private void getGameType(){
        mode = view.requestGameType();
    }

    private void startGame(){
        if (mode == null  || mode.getClass().isInstance(new FixedType())){
            mode = new FixedType();
        }
        else{
            mode = new RandomType();
        }
        startLoop();
    }

    private void startLoop()
    {   count = 0;
        view.displayBoard(mode);
        Point dogNewPos = null;
       // number of sheep always less than pen size
        System.out.println("Move made: " + count);
        while (mode.getSheepNum()!= 0){
            // dog's current position
            Point dogCurrPos = mode.getDogPos();

            // dog's next valid position
            dogNewPos = askForValidMove();

            // move dog
            mode.moveDog(dogNewPos);

            //move sheep
            mode.moveSheep();

            // if sheep is in pen, remove from list of sheep
            mode.removeSheepFromPen();

            // Show the updated state of the board.
            view.displayBoard(mode);
        }

        if(mode.getSheepNum()== 0){
            System.out.println("You won, all sheep are in pen!");
            System.out.println("Would you like to start a new game? Enter yes or no");
            String yesOrNo = Input.readStringFromUser();
            if (yesOrNo.equalsIgnoreCase("yes")){
                beginSession();
                count = 0;
            }
            else{
                System.exit(0);
            }
        }

    }

    private Point askForValidMove() {
        boolean moveRejected = true;
        Point dogCurrPos;
        // Ask for a move until a valid move is submitted by the player
        boolean acceptedInput;
        do {
            char chosenMove = mode.chooseMove();
            count+=1;
            System.out.println("Move made: " + count);
            acceptedInput = mode.checkMoveInput(chosenMove);
            dogCurrPos = mode.getDogPos();
            // check if input is appropriate
            if (acceptedInput == false) {
                System.out.println("Move must be a, w, d, or s!");
                continue;
            }
            // get dog's next position
            Point dogNextPos = pointClass.convertCharToPoint(chosenMove, dogCurrPos);
            //Check the move's validity.
            moveRejected = mode.isValidMove(dogNextPos);
            // If rejected, display an error message.
            if (moveRejected == false) {
                view.displayMoveRejectedMessage(chosenMove);
                continue;
            }
            dogCurrPos = dogNextPos;
        }
        while (moveRejected == false || acceptedInput == false);

        return dogCurrPos;
    }
}
